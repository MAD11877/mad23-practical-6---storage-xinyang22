package sg.edu.np.mad.week6practical;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class DBHandler extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "userDB";

    private static final String TABLE_USERS = "users";
    private static final String KEY_ID = "id";
    private static final String KEY_NAME = "name";
    private static final String KEY_DESCRIPTION = "description";
    private static final String KEY_VALUE = "value";
    private static final String KEY_FOLLOWED = "followed";

    public DBHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + "("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KEY_NAME + " TEXT,"
                + KEY_DESCRIPTION + " TEXT,"
                + KEY_VALUE + " INTEGER,"
                + KEY_FOLLOWED + " INTEGER"
                + ")";
        db.execSQL(CREATE_USERS_TABLE);

        // Generate and insert 20 random user data
        Random random = new Random();
        for (int i = 0; i < 20; i++) {
            ContentValues values = new ContentValues();
            values.put(KEY_NAME, "User " + i);
            values.put(KEY_DESCRIPTION, "Description " + i);
            values.put(KEY_VALUE, random.nextInt(100));
            values.put(KEY_FOLLOWED, random.nextBoolean() ? 1 : 0);
            db.insert(TABLE_USERS, null, values);
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    public List<User> getUsers() {
        List<User> userList = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_USERS;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                User user = new User();
                user.setId(cursor.getInt(cursor.getColumnIndex(KEY_ID)));
                user.setName(cursor.getString(cursor.getColumnIndex(KEY_NAME)));
                user.setDescription(cursor.getString(cursor.getColumnIndex(KEY_DESCRIPTION)));
                user.setValue(cursor.getInt(cursor.getColumnIndex(KEY_VALUE)));
                user.setFollowed(cursor.getInt(cursor.getColumnIndex(KEY_FOLLOWED)) == 1);
                userList.add(user);
            } while (cursor.moveToNext());
        }

        cursor.close();
        return userList;
    }

    public void updateUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_NAME, user.getName());
        values.put(KEY_DESCRIPTION, user.getDescription());
        values.put(KEY_VALUE, user.getValue());
        values.put(KEY_FOLLOWED, user.isFollowed() ? 1 : 0);

        db.update(TABLE_USERS, values, KEY_ID + " = ?", new String[]{String.valueOf(user.getId())});
    }
}

