package sg.edu.np.mad.week6practical;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MainActivity extends AppCompatActivity implements UserAdapter.UserClickListener {

    private RecyclerView recyclerView;
    private UserAdapter userAdapter;
    private DBHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        dbHandler = new DBHandler(this);

        // Populate RecyclerView with data from the database
        List<User> userList = dbHandler.getUsers();
        userAdapter = new UserAdapter(userList, this);
        recyclerView.setAdapter(userAdapter);
    }

    @Override
    public void onFollowButtonClick(int position) {
        User user = userAdapter.getUserList().get(position);
        user.setFollowed(!user.isFollowed());
        dbHandler.updateUser(user);
        userAdapter.notifyItemChanged(position);
        Toast.makeText(this, "User updated", Toast.LENGTH_SHORT).show();
    }
}
