package sg.edu.np.mad.week6practical;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.UserViewHolder> {

    private List<User> userList;
    private UserClickListener listener;

    public interface UserClickListener {
        void onFollowButtonClick(int position);
    }

    public UserAdapter(List<User> userList, UserClickListener listener) {
        this.userList = userList;
        this.listener = listener;
    }

    public List<User> getUserList() {
        return userList;
    }

    @NonNull
    @Override
    public UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_user, parent, false);
        return new UserViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull UserViewHolder holder, int position) {
        User user = userList.get(position);
        holder.tvName.setText(user.getName());
        holder.tvDescription.setText(user.getDescription());
        holder.tvValue.setText(String.valueOf(user.getValue()));
        holder.btnFollow.setText(user.isFollowed() ? "Unfollow" : "Follow");
    }

    @Override
    public int getItemCount() {
        return userList.size();
    }

    public class UserViewHolder extends RecyclerView.ViewHolder {

        TextView tvName, tvDescription, tvValue;
        Button btnFollow;

        public UserViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvName);
            tvDescription = itemView.findViewById(R.id.tvDescription);
            tvValue = itemView.findViewById(R.id.tvValue);
            btnFollow = itemView.findViewById(R.id.btnFollow);

            btnFollow.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        listener.onFollowButtonClick(position);
                    }
                }
            });
        }
    }
}
